﻿/*
Problem 6. Most frequent number

Write a script that finds the most frequent number in an array.
Example:

input	                                 result
4, 1, 1, 4, 2, 3, 4, 4, 1, 2, 4, 9, 3	 4 (5 times)
*/

function MaxFrequentNumber() {
    var counter = 1, maxCount = 0, index, array = [4, 1, 1, 4, 2, 3, 4, 4, 1, 2, 4, 9, 3];
    for (var i = 0; i < array.length; i++) {
        for (var j = i + 1; j < array.length; j++) {
            if (array[i] === array[j]) {
                counter += 1;
            }
        }
        if (maxCount < counter) {
            maxCount = counter;
            index = array[i];
        }
        counter = 1;
    }

    console.log(index + "(" + maxCount + " times)");
}