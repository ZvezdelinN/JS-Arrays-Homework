﻿/*
Problem 7. Binary search

Write a script that finds the index of given element in a sorted array of integers by using the binary search algorithm.
*/

function BinarySearch() {
    var numberToFind = 0, buffer, iterattions = 1, found = false, startIndex = 0, endIndex = array.length-1, arrayLength = array.length, array =  [1, 6, 4, 3, 9, 8, 21, 8, 7, 34, 99];
    while (iterattions !== 0) {
        for (var i = 1; i < arrayLength; i++) {
            if (array[i - 1] > array[i]) {
                buffer = array[i - 1];
                array[i - 1] = array[i];
                array[i] = buffer;
                iterattions += 1;
            }
        }
        if (iterattions > 1) {
            iterattions = 1;
        } else {
            iterattions = 0;
        }
    }

    console.log(array);

    while (!found) {
        if (numberToFind < (array[arrayLength / 2])) {
            endIndex = arrayLength - 1;
        } else if (numberToFind > (array[arrayLength / 2])) {
            startIndex = arrayLength + 1;
        } else {

        }


    }
}