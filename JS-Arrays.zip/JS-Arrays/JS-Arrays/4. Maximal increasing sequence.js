﻿/*
Problem 4. Maximal increasing sequence

Write a script that finds the maximal increasing sequence in an array.
Example:

input	               result
3, 2, 3, 4, 2, 2, 4	   2, 3, 4
*/

function MaxIncreaseSequence() {
    var startIndex, endIndex, counterSequence = 1, maxSequence = 1,
        array = [3, 2, 3, 4, 2, 2, 4];
    for (var i = 1; i < array.length; i++) {
        if (array[i] === (array[i - 1] + 1)) {
            counterSequence += 1;
        } else {
            if (maxSequence < counterSequence) {
                maxSequence = counterSequence;
                startIndex = i - maxSequence;
                endIndex = i;
                counterSequence = 1;
            }
        }
    }

    console.log("Start : " + startIndex + ", end: " + endIndex);
    for (var i = startIndex; i < endIndex; i++) {
        console.log(array[i]);
    }
}