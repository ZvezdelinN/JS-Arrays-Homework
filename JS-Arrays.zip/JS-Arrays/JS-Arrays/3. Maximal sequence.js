﻿/*
Problem 3. Maximal sequence

Write a script that finds the maximal sequence of equal elements in an array.
Example:

input	                        result
2, 1, 1, 2, 3, 3, 2, 2, 2, 1	2, 2, 2
*/

function MaxSequence() {
    var startIndex, endIndex, counterSequence = 1, maxSequence = 1,
        array = [2, 1, 1, 1, 1, 2, 3, 3, 2, 2, 2, 1];
    for (var i = 1; i <= array.length; i++) {
        if (array[i] === array[i-1]) {
            counterSequence += 1;
        } else {
            if (maxSequence < counterSequence) {
                maxSequence = counterSequence;
                startIndex = i - maxSequence;
                endIndex = i;
                counterSequence = 1;
            }
        }
    }
    for (var i = startIndex; i < endIndex; i++) {
        console.log(array[i]);
    }
}