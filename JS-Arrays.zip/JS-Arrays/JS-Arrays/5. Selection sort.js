﻿/*
Problem 5. Selection sort

Sorting an array means to arrange its elements in increasing order.
Write a script to sort an array.
Use the selection sort algorithm: Find the smallest element, move it at the first position, find the smallest from the rest, move it at the second position, etc.
Hint: Use a second array
*/

function SelectionSort() {
    var counterSortedArray = 0, smallestElement, position, array = [1, 6, 4, 3, 9, 8, 21, 8, 7, 34, 99], sortedArray = [];
    console.log(array);
    while (array[0] !== undefined) {
        smallestElement = array[0];
        for (var i = 0; i < array.length; i++) {
            if (smallestElement > array[i]) {
                smallestElement = array[i];
                position = i;
            }
        }
        sortedArray[counterSortedArray] = smallestElement;
        array.splice(position, 1);
        counterSortedArray += 1;
        position = 0;
    }

    console.log(sortedArray);
}