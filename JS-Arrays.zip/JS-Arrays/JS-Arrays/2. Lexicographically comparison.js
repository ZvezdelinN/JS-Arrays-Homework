﻿/*
Problem 2. Lexicographically comparison

Write a script that compares two char arrays lexicographically (letter by letter).
*/

function StringComparison(firstString, secondString) {
    var shorterString = firstString.length;
    if (firstString.length > secondString.length) {
        shorterString = secondString.length;
    }
    firstString = firstString || "empty";
    secondString = secondString || "empty";
    for (var i = 0; i < shorterString; i++) {
        if (firstString[i] !== secondString[i]) {
            console.log(firstString + " isn't equal to " + secondString);
            return;
        }  
    }

    if ((firstString.length - secondString.length) === 0) {
        console.log(firstString + " is equal to " + secondString);
    } else {
        console.log(firstString + " isn't equal to " + secondString);
    }
}